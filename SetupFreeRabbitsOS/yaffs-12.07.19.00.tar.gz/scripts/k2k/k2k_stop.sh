#/bin/bash

cd $(dirname $0)
. k2k_setup.sh

logger -s "k2k. stop."

k2k_pidfile_kill "$K2K_TALK_PIDFILE"
k2k_pidfile_kill "$K2K_LISTEN_PIDFILE"

if [ -f "$K2K_REMOTEIP_FILE" ] ; then
    REMOTEIP=$(cat "$K2K_REMOTEIP_FILE")
    echo "stop" | nc $REMOTEIP $K2K_CMD_PORT
    rm "$K2K_REMOTEIP_FILE"
else
    echo "no remote ip file"
fi
