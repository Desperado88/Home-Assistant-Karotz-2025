#!/bin/sh

while read line </dev/ttyGS0 ; do
    if [ ! -z "$line" ] ; then
        echo "$line" | /usr/scripts/config.py
    fi
done
