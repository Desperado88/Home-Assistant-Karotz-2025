#!/bin/bash

echo "[Check message size] start"

MESSAGEPATH="/usr/karotz/messages/"

MAXSIZE=1000000
MAXTIME=10

SIZE=`du -s $MESSAGEPATH | cut -f1`
echo $SIZE

while [ $SIZE -ge $MAXSIZE ] ; do
    echo "WHILE"
    echo $MAXTIME
    echo $SIZE
    echo `find $MESSAGEPATH -type f -mtime +$MAXTIME -exec rm {} \;`
    SIZE=`du -s $MESSAGEPATH | cut -f1`
    let "$((MAXTIME--))" 

    if [ $MAXTIME -eq 1 ]; then
        break
    fi
done

echo "[Check message size] end"
