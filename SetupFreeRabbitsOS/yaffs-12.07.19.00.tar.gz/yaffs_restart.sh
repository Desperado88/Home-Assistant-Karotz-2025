#!/bin/bash
/usr/yaffs_stop.sh
/usr/yaffs_start.sh
