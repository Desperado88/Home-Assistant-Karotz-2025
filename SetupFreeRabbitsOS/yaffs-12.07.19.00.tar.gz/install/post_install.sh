#!/bin/bash

cp -a /tmp/update_yaffs/install/sys_version /usr/etc/conf/sys_version

exit 0
