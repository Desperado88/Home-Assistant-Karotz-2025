#!/bin/bash

IP_YOANN="10.104.2.124"
PATH_YOANN="/home/yoann/workspace/karotz2/build-arm"

IP_PIERRE=""
PATH_PIERRE=""

IP_GUILLAUME=""
PATH_GUILLAUME=""

IP_DAVID=""
PATH_DAVID=""

function usage() {
    echo "mount_nfs.sh <person>"
    echo -e "Persons :\tyoann"
    echo -e "\t\tpierre"
    echo -e "\t\tguillaume"
    echo -e "\t\tdavid"
    echo "You can enter an IP address if the person is not present in the list."
    exit 1
}

[ $# -ne 1 ] && usage;

echo $#

if [ "$1" = "yoann" ]; then
    IP=$IP_YOANN
    PATH_NFS=$PATH_YOANN
elif [ "$1" = "pierre" ]; then
    IP=$IP_PIERRE
    PATH_NFS=$PATH_PIERRE
elif [ "$1" = "guillaume" ]; then
    IP=$IP_GUILLAUME
    PATH_NFS=$PATH_GUILLAUME
elif [ "$1" = "david" ]; then
    IP=$IP_DAVID
    PATH_NFS=PATH_DAVID
fi

[ ! -e /usr/nfs ] && mkdir -p /usr/nfs
[ ! -e /usr/nfs/$1 ] && mkdir -p /usr/nfs/$1

mount -t nfs -o nolock $IP:$PATH_NFS /usr/nfs/$1
